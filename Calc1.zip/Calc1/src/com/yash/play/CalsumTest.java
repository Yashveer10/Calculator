package com.yash.play;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import com.yash.play.*;

public class CalsumTest {

	@Test
	void testAdd() {
		Calsum c=new Calsum();
		int x=20;
		int y=10;
		
		int actual =c.add(x, y);
		int expected=30;
		assertEquals(expected, actual);
	}

	@Test
	void testSub() {
		Calsum c=new Calsum();
		int x=20;
		int y=10;
		
		int actual =c.sub(x, y);
		int expected=10;
		assertEquals(expected, actual);
	}

	@Test
	void testMul() {
		Calsum c=new Calsum();
		int x=20;
		int y=10;
		
		int actual =c.mul(x, y);
		int expected=200;
		assertEquals(expected, actual);
	}

	@Test
	void testDiv() {
		Calsum c=new Calsum();
		int x=20;
		int y=10;
		
		int actual =c.div(x, y);
		int expected=2;
		assertEquals(expected, actual);
	}
}
